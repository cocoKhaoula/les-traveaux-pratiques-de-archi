package isetj.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "CoffeeServlet", urlPatterns = { "/CoffeeServlet" })
public class cupofcoffeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String option;
	private String zone;
	
	public cupofcoffeServlet() {
        super();
        
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		option = request.getParameter("R");
		zone = request.getParameter("T");
		response.getWriter().println("<!DOCTYPE html>\r\n"
				+ "<html>\r\n"
				+ "<head>\r\n"
				+ "<meta charset=\"ISO-8859-1\">\r\n"
				+ "<title>Cup Of Coffee</title>\r\n"
				+ "</head>\r\n"
				+ "<body>\r\n"
				+ "<img src=\"https://www.freepik.com/free-vector/hand-drawn-latte-art-drink_14723637.htm#query=coffee%20cup%20drawing&position=9&from_view=keyword&track=ais\" width=\"300\" height=\"300\">");
		response.getWriter().println("<br><p> merci de nous avoir fait parvenirla remarque suivant <b>"+option+"</b> bonne</p>"); 
		response.getWriter().println("<br> votre demande: <b>"+zone+"</b></body></html>");}}
	
		

