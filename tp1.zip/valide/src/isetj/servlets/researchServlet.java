package isetj.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class researchServlet  extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	public researchServlet() {
		super();
	}
	
	 protected void doGet (HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
       String res=request.getParameter("R");
        String moteur=request.getParameter("O");

              if (moteur.equals("yahoo")){
	             response.sendRedirect("https://www.yahoo.com/search?q="+res);
             }else if (moteur.equals("google")){
	             response.sendRedirect("https://www.google.com/search?q="+res);		}
      }
	 protected void doPost(HttpServletRequest request,HttpServletResponse response )throws ServletException,IOException{}
	 }
