package isetj.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class comptServlet extends HttpServlet {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int compteur;
	
	 public void init() throws ServletException {
		 compteur = 1;
	    }

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
	        
	        compteur++;
	        
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html><head>\r\n"
	        		+ "<meta charset=\"ISO-8859-1\">\r\n"
	        		+ "<title>Incrementation</title>\r\n"
	        		+ "</head><body>");
	        out.println("<h1>Nombre d'appels de la servlet : " + compteur + "</h1>");
	        out.println("</body></html>");
	    }
	}

